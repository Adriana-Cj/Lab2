

<?php $__env->startSection('title', 'Acasă'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Bine ați venit la To-Do App pentru echipe</h1>
    <p>Organizați-vă sarcinile și colaborați eficient cu echipa dumneavoastră.</p>

    
    <?php if(isset($latestTask)): ?>
        <section class="mt-6">
            <h2>Ultima sarcină adăugată:</h2>
            <div class="mt-4">
                <?php if (isset($component)) { $__componentOriginal5c7e45c1b38a85fb63a7b75e56a24d35 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c7e45c1b38a85fb63a7b75e56a24d35 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.task-card','data' => ['task' => $latestTask]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('task-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['task' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($latestTask)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c7e45c1b38a85fb63a7b75e56a24d35)): ?>
<?php $attributes = $__attributesOriginal5c7e45c1b38a85fb63a7b75e56a24d35; ?>
<?php unset($__attributesOriginal5c7e45c1b38a85fb63a7b75e56a24d35); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c7e45c1b38a85fb63a7b75e56a24d35)): ?>
<?php $component = $__componentOriginal5c7e45c1b38a85fb63a7b75e56a24d35; ?>
<?php unset($__componentOriginal5c7e45c1b38a85fb63a7b75e56a24d35); ?>
<?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <nav>
        <h2>Navigație rapidă:</h2>
        <ul>
            <li><a href="<?php echo e(route('tasks.index')); ?>">Lista de sarcini</a></li>
            <li><a href="<?php echo e(route('tasks.create')); ?>">Crearea unei sarcini noi</a></li>
        </ul>
    </nav>

    <section>
        <h2>Despre aplicația noastră</h2>
        <p>To-Do App pentru echipe este o aplicație simplă și eficientă pentru gestionarea sarcinilor în cadrul echipelor. Principalele funcții includ:</p>
        <ul>
            <li>Crearea și atribuirea sarcinilor</li>
            <li>Urmărirea progresului</li>
            <li>Colaborare în timp real</li>
            <li>Notificări și termene limită</li>
        </ul>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\todo-app\resources\views/home.blade.php ENDPATH**/ ?>
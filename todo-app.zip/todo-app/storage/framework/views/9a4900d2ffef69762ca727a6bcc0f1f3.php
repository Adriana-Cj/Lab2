

<?php $__env->startSection('title', 'Despre Noi'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Despre Noi</h1>
    <p>Bine ați venit la aplicația noastră Todo! Această aplicație vă ajută să vă gestionați sarcinile zilnice eficient.</p>
    
    <h2>Misiunea Noastră</h2>
    <p>Misiunea noastră este să oferim un instrument simplu și intuitiv pentru gestionarea sarcinilor, care ajută atât persoanele, cât și echipele să rămână organizate și productive.</p>
    
    <h2>Contactați-ne</h2>
    <p>Dacă aveți întrebări sau sugestii, nu ezitați să ne contactați la: support@todoapp.com</p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\todo-app\resources\views/about.blade.php ENDPATH**/ ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['task']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['task']); ?>
<?php foreach (array_filter((['task']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="task-card">
    <h2><?php echo e($task['title'] ?? 'Fără titlu'); ?></h2>
    <div class="task-info">
        <?php if(isset($task['description'])): ?>
            <p><?php echo e($task['description']); ?></p>
        <?php endif; ?>
        <p><strong>Creat la:</strong> <?php echo e($task['created_at'] ?? 'Necunoscut'); ?></p>
        <p><strong>Actualizat la:</strong> <?php echo e($task['updated_at'] ?? 'Necunoscut'); ?></p>
        <p><strong>Stare:</strong> <?php echo e(isset($task['completed']) ? ($task['completed'] ? 'Finalizată' : 'Nefinalizată') : 'Necunoscut'); ?></p>
        <p><strong>Prioritate:</strong> <?php if (isset($component)) { $__componentOriginal7b490c3ef6cdf49161011ba5be3d33a3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b490c3ef6cdf49161011ba5be3d33a3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.task-priority','data' => ['priority' => $task['priority'] ?? 'Necunoscută']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('task-priority'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['priority' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($task['priority'] ?? 'Necunoscută')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b490c3ef6cdf49161011ba5be3d33a3)): ?>
<?php $attributes = $__attributesOriginal7b490c3ef6cdf49161011ba5be3d33a3; ?>
<?php unset($__attributesOriginal7b490c3ef6cdf49161011ba5be3d33a3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b490c3ef6cdf49161011ba5be3d33a3)): ?>
<?php $component = $__componentOriginal7b490c3ef6cdf49161011ba5be3d33a3; ?>
<?php unset($__componentOriginal7b490c3ef6cdf49161011ba5be3d33a3); ?>
<?php endif; ?></p>
        <p><strong>Responsabil:</strong> <?php echo e($task['assigned_to'] ?? 'Nealocat'); ?></p>
    </div>
    <div class="task-actions">
        <a href="<?php echo e(route('tasks.edit', $task['id'])); ?>" class="btn btn-edit">Editează</a>
        <form action="<?php echo e(route('tasks.destroy', $task['id'])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-delete">Șterge</button>
        </form>
    </div>
</div>

<?php /**PATH C:\xampp\todo-app\resources\views/components/task-card.blade.php ENDPATH**/ ?>
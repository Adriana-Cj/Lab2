<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['priority']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['priority']); ?>
<?php foreach (array_filter((['priority']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $priorityClasses = [
        'Scăzută' => 'bg-green-100 text-green-800 border-green-300',
        'Medie' => 'bg-yellow-100 text-yellow-800 border-yellow-300',
        'Ridicată' => 'bg-red-100 text-red-800 border-red-300'
    ];

    $priorityIcons = [
        'Scăzută' => '⬇️',
        'Medie' => '➡️',
        'Ridicată' => '⬆️'
    ];

    $classes = $priorityClasses[$priority] ?? 'bg-gray-100 text-gray-800 border-gray-300';
    $icon = $priorityIcons[$priority] ?? '❓';
?>

<div <?php echo e($attributes->merge(['class' => "inline-flex items-center px-3 py-1 rounded-full border {$classes}"])); ?>>
    <span class="mr-1"><?php echo e($icon); ?></span>
    <span class="font-medium"><?php echo e($priority); ?></span>
</div>

<?php /**PATH C:\xampp\todo-app\resources\views/components/task-priority.blade.php ENDPATH**/ ?>
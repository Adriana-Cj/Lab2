<?php
namespace App\ViewComposers;

use Illuminate\View\View;

class LatestTaskComposer
{
    private function getTasksFromController()
    {
        return [
            [
                'id' => 1,
                'title' => 'Finalizare proiect',
                'description' => 'Descrierea proiectului 1',
                'status' => 'În progres',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Medie',
                'assigned_to' => 'Adriana'
            ],
            [
                'id' => 2,
                'title' => 'Finalizare proiect',
                'description' => 'Descrierea proiectului 1',
                'status' => 'Finalizat',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Ridicată',
                'assigned_to' => 'Adriana'
            ],
            [
                'id' => 3,
                'title' => 'Finalizare proiect',
                'description' => 'Descrierea proiectului 1',
                'status' => 'În progres',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Scăzută',
                'assigned_to' => 'Andrei'
            ],
        ];
    }

    public function compose(View $view)
    {
        $tasks = $this->getTasksFromController();
        // Luăm ultima sarcină din array (cea mai recentă)
        $latestTask = end($tasks);
        
        $view->with('latestTask', $latestTask);
    }
}

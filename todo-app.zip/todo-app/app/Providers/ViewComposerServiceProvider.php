<?php
namespace App\Providers;

use App\ViewComposers\LatestTaskComposer;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;

class ViewComposerServiceProvider extends ServiceProvider
{
    public function register()
    {
        //
    }

    public function boot()
    {
        View::composer('home', LatestTaskComposer::class);
    }
}
?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function index()
    {
        $tasks = [
            [
                'id' => 1,
                'title' => 'Finalizare proiect',
                'description' => 'Descrierea proiectului 1',
                'status' => 'În progres',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Medie',
                'assigned_to' => 'Adriana'
            ],
            [
                'id' => 2,
                'title' => 'Finalizare proiect',
                'description' => 'Descrierea proiectului 2',
                'status' => 'Finalizat',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Ridicată',
                'assigned_to' => 'Adriana'
            ],
            [
                'id' => 3,
                'title' => 'Finalizare proiect',
                'description' => 'Descrierea proiectului 3',
                'status' => 'În progres',
                'created_at' => now()->subDays(5)->format('Y-m-d H:i:s'),
                'updated_at' => now()->subDay()->format('Y-m-d H:i:s'),
                'completed' => false,
                'priority' => 'Scăzută',
                'assigned_to' => 'Alexandru'
            ],
        
    
        ];

        return view('tasks.index', ['tasks' => $tasks]);
    }

    public function show($id)
    {
        $task = [
            'id' => $id,
            'title' => 'Titlul sarcinii ' . $id,
            'description' => 'Descrierea detaliată a sarcinii ' . $id, 
            'created_at' => now()->subDays(rand(1, 30))->format('Y-m-d H:i:s'),
            'updated_at' => now()->subDays(rand(0, 5))->format('Y-m-d H:i:s'),
            'completed' => rand(0, 1) == 1,
            'priority' => ['Scăzută', 'Medie', 'Ridicată'][rand(0, 2)],
            'assigned_to' => ['Adriana', 'Marcel', 'Andrei'][rand(0, 2)],
        ];

        return view('tasks.show', ['task' => $task]);
    }

    public function create()
    {
       
    }

    public function store(Request $request)
    {
       
    }


    public function edit($id)
    {
       
    }

    public function update(Request $request, $id)
    {
        
    }

    public function destroy($id)
    {
        
    }
}
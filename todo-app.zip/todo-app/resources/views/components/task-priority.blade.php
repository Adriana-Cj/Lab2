@props(['priority'])

@php
    $priorityClasses = [
        'Scăzută' => 'bg-green-100 text-green-800 border-green-300',
        'Medie' => 'bg-yellow-100 text-yellow-800 border-yellow-300',
        'Ridicată' => 'bg-red-100 text-red-800 border-red-300'
    ];

    $priorityIcons = [
        'Scăzută' => '⬇️',
        'Medie' => '➡️',
        'Ridicată' => '⬆️'
    ];

    $classes = $priorityClasses[$priority] ?? 'bg-gray-100 text-gray-800 border-gray-300';
    $icon = $priorityIcons[$priority] ?? '❓';
@endphp

<div {{ $attributes->merge(['class' => "inline-flex items-center px-3 py-1 rounded-full border {$classes}"]) }}>
    <span class="mr-1">{{ $icon }}</span>
    <span class="font-medium">{{ $priority }}</span>
</div>


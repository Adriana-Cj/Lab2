<header>
    <div class="container">
        <h1>{{ $title ?? 'Todo App' }}</h1>
        <nav>
            <ul>
                <li><a href="{{ route('home') }}">Acasă</a></li>
                <li><a href="{{ route('tasks.index') }}">Sarcini</a></li>
                <li><a href="{{ route('about') }}">Despre</a></li>
            </ul>
        </nav>
    </div>
</header>
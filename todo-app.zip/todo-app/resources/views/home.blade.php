@extends('layouts.app')

@section('title', 'Acasă')

@section('content')
    <h1>Bine ați venit la To-Do App pentru echipe</h1>
    <p>Organizați-vă sarcinile și colaborați eficient cu echipa dumneavoastră.</p>

    {{-- Adăugăm secțiunea pentru ultima sarcină --}}
    @if(isset($latestTask))
        <section class="mt-6">
            <h2>Ultima sarcină adăugată:</h2>
            <div class="mt-4">
                <x-task-card :task="$latestTask" />
            </div>
        </section>
    @endif

    <nav>
        <h2>Navigație rapidă:</h2>
        <ul>
            <li><a href="{{ route('tasks.index') }}">Lista de sarcini</a></li>
            <li><a href="{{ route('tasks.create') }}">Crearea unei sarcini noi</a></li>
        </ul>
    </nav>

    <section>
        <h2>Despre aplicația noastră</h2>
        <p>To-Do App pentru echipe este o aplicație simplă și eficientă pentru gestionarea sarcinilor în cadrul echipelor. Principalele funcții includ:</p>
        <ul>
            <li>Crearea și atribuirea sarcinilor</li>
            <li>Urmărirea progresului</li>
            <li>Colaborare în timp real</li>
            <li>Notificări și termene limită</li>
        </ul>
    </section>
@endsection


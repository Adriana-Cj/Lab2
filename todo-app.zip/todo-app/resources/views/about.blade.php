@extends('layouts.app')

@section('title', 'Despre Noi')

@section('content')
    <h1>Despre Noi</h1>
    <p>Bine ați venit la aplicația noastră Todo! Această aplicație vă ajută să vă gestionați sarcinile zilnice eficient.</p>
    
    <h2>Misiunea Noastră</h2>
    <p>Misiunea noastră este să oferim un instrument simplu și intuitiv pentru gestionarea sarcinilor, care ajută atât persoanele, cât și echipele să rămână organizate și productive.</p>
    
    <h2>Contactați-ne</h2>
    <p>Dacă aveți întrebări sau sugestii, nu ezitați să ne contactați la: support@todoapp.com</p>
@endsection

